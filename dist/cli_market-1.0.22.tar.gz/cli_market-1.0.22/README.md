<p align="center"><img src="https://raw.githubusercontent.com/Treevu-ai/cli-market-world/main/social-preview.svg" alt="CLI Market" width="600"/></p>

<p align="center">
  <img src="https://img.shields.io/badge/retailers-3760+-brightgreen" alt="3760 retailers">
  <img src="https://img.shields.io/badge/lines-12-blue" alt="12 lines">
  <img src="https://img.shields.io/badge/countries-67-orange" alt="67 countries">
  <img src="https://img.shields.io/badge/MCP%20tools-12-00d75f" alt="MCP">
  <img src="https://img.shields.io/badge/python-3.10+-306998" alt="py">
  <img src="https://img.shields.io/badge/license-MIT-lightgrey" alt="MIT">
  <img src="https://img.shields.io/badge/build-passing-brightgreen" alt="build">
  <img src="https://img.shields.io/badge/CI-vercel-black" alt="Vercel">
</p>

<p align="center">
  <a href="https://pypi.org/project/cli-market/"><img src="https://img.shields.io/pypi/v/cli-market?color=00FF88" alt="PyPI version"></a>
  <a href="https://pypi.org/project/cli-market/"><img src="https://img.shields.io/pypi/dm/cli-market?color=00FF88" alt="PyPI downloads"></a>
  <a href="https://github.com/Treevu-ai/cli-market-world"><img src="https://img.shields.io/github/stars/Treevu-ai/cli-market-world?style=social" alt="GitHub stars"></a>
  <a href="https://www.producthunt.com/products/cli-market"><img src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=1150344&amp;theme=neutral" alt="ProductHunt featured" width="125" height="27"></a>
</p>


<!-- mcp-name: io.github.Treevu-ai/cli-market -->

<h1 align="center">CLI Market</h1>
<p align="center"><b>Commerce infrastructure for AI agents.</b><br>3,760+ retailers · 12 lines · 67 countries · 1 API.</p>

---

## What is CLI Market?

**The problem:** AI agents can't comparison-shop autonomously today. 3,760 VTEX retailers — Nike, Carrefour, Samsung, Motorola — all share the same public API. But every retailer requires separate auth, separate search logic, no unified cart state, no cross-retailer pricing. Agents fail before the first query.

**CLI Market fixes this.** One API call across all retailers. One `pip install`. One JSON schema.

- **Search** any product across 3,760 retailers in 67 countries
- **Compare** prices cross-border in real time
- **Purchase** autonomously via 12 MCP tools
- **Build** on our data moat — SQLite snapshots of pricing history, SKU normalization, cross-retailer intelligence

> Stripe turned payments into APIs. We turn commerce into APIs.

<p align="center"><a href="https://cli-market.dev"><b>cli-market.dev</b></a> — full landing, live coverage, MCP docs</p>

![CLI Market demo](https://raw.githubusercontent.com/Treevu-ai/cli-market-world/main/demo.gif)

## Quick start

### Linux / macOS / WSL

```bash
# 1. Install
pip install cli-market

# 2. Start backend
market-server &

# 3. Use the CLI
market login
market search "leche" --country PE
market compare "aceite"
market add 3 --qty 2
market checkout --payment yape

# 4. Agent mode
market ask "compra arroz"
market --json
```

### Windows (PowerShell)

```powershell
# 1. Install
pip install cli-market

# 2. Start backend (in a separate terminal)
Start-Process -NoNewWindow python -ArgumentList "-m", "market_server"

# 3. Use the CLI
market login
market search "leche" --country PE
market compare "aceite"
market add 3 --qty 2
market checkout --payment yape

# 4. Agent mode
market ask "compra arroz"
market --json
```

### Windows (CMD)

```cmd
:: 1. Install
pip install cli-market

:: 2. Start backend (in a separate terminal)
start python -m market_server

:: 3. Use the CLI
market login
market search "leche" --country PE
market compare "aceite"
market add 3 --qty 2
market checkout --payment yape

:: 4. Agent mode
market ask "compra arroz"
market --json
```

## Features

| For humans | For AI agents |
|---|---|
| Terminal CLI | REST API + JSON |
| Rich tables | 12 MCP Tools |
| Spanish / English | CSV export |
| `market search "milk"` | Autonomous workflows |

### Commands

`login` `lines` `search` `compare` `add` `cart` `cart-update` `cart-remove` `cart-clear` `checkout` `orders` `reorder` `ask` `--json`

### MCP Server

```bash
python market_mcp.py
```

12 tools: `market_login` `market_lines` `market_search` `market_compare` `market_add` `market_cart` `market_cart_update` `market_cart_remove` `market_checkout` `market_orders` `market_reorder` `market_ask`

Compatible with DeepSeek TUI, Claude, Cursor, and any MCP client.

## Coverage

3,760+ retailers across 12 business lines in 67 countries.

| Line | Count | Key retailers |
|------|-------|--------------|
| 👕 Fashion | 1,560 | Louis Vuitton · Gucci · Prada · Chanel · Dior · Zara · H&M · Levi's · Nike · Adidas · Renner · Lamborghini · Ferrari |
| 📱 Electronics | 571 | Samsung · Apple · Sony · LG · Panasonic · Dell · HP · Lenovo · Yamaha · Dyson |
| 🏠 Home | 314 | IKEA · Homecenter · Sodimac · Miele · Bosch · Smeg · Tefal · KitchenAid |
| ⚽ Sports | 306 | Nike · Adidas · Reebok · Puma · Under Armour · Decathlon · Foot Locker · Patagonia |
| 🛒 Supermarkets | 252 | Wong · Carrefour · Jumbo · Coto · Costco · Sainsbury's · Edeka · Albert Heijn |
| 🍔 Food | 176 | Nestle · Unilever · Coca-Cola · Pepsi · Lindt · Heineken · Nespresso |
| 💄 Beauty | 170 | Sephora · MAC · Clinique · Estee Lauder · Lancome · Lush · Yves Rocher |
| 🏬 Department Stores | 136 | Mercado Libre · El Corte Ingles · Otto · Miniso · Lego · Americanas |
| 💊 Pharmacies | 51 | Droga Raia · Drogasil · Boots · DM · Rossmann |
| 🔧 Auto Parts | 50 | BMW · Mercedes-Benz · Audi · Tesla · Harley Davidson · Ducati |
| 📚 Stationery | 11 | Staples · Office Depot |


**Countries:** 67 countries across LATAM, Europe, and global

## API

```
Base URL: https://cli-market-api.onrender.com
Swagger:  /docs
llms.txt: https://cli-market.dev/llms.txt
```

### Endpoints

```bash
# Status
GET /

# Data Feed
GET /v1/feed/prices?query=cafe&country=PE&format=csv
GET /v1/feed/stats?period=7d

# Competitive Intelligence (CIaaS)
GET /v1/intel/competitor?product=leche&store_a=wong&store_b=plazavea
GET /v1/intel/delta?product=cafe&country_a=PE&country_b=CO
GET /v1/intel/alerts?product=arroz&threshold_pct=5

# Pricing
GET /v1/pricing
```

### Rate limits

| Tier | Requests/min | Requests/day | CIaaS |
|------|-------------|-------------|-------|
| Free | 10 | 100 | No |
| Paid | Contact | Contact | Yes |

## Architecture

```
AI Agents (Claude, DeepSeek, GPT)
        |
   CLI Market API    ← You are here
        |
   3,760+ VTEX retailers across 67 countries
        |
  SQLite data moat — price snapshots, search history
```

## Why this exists

E-commerce is optimized for clicks, not agents. VTEX powers 3,760+ retailers with the same public API — yet no one has built a unified agentic layer on top. CLI Market is that layer.

## Links

- Landing: [cli-market.dev](https://cli-market.dev)
- API: [cli-market-api.onrender.com](https://cli-market-api.onrender.com)
- Telegram: [@climarketbot](https://t.me/climarketbot)
- llms.txt: [cli-market.dev/llms.txt](https://cli-market.dev/llms.txt)

## Legal

**Software:** MIT License. Use, modify, distribute freely.

**Data:** Pricing data, SKU mappings, historical snapshots, and retailer indexes are proprietary. Licensed under the [Data License Agreement](legal/Data_License_Agreement.md). The software is open. The data moat is protected.

**Documents:**
- [Terms of Service](legal/ToS.md)
- [Privacy Policy](legal/Privacy.md)
- [Data License Agreement](legal/Data_License_Agreement.md)
- [Acceptable Use Policy](legal/AUP.md)
- [Service Level Agreement](legal/SLA.md)

MIT © 2026 CLI Market · Treevu AI
